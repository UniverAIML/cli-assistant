"""CLI Assistant - A CLI tool for development workflows."""

__version__ = "0.1.0"
__author__ = "Univer AI ML"
